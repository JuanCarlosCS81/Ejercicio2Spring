//https://github.com/JuanCarlosCS81/Ejercicio2Spring.git

package com.example.acdspringejercicio2tutorial;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * JUAN CARLOS CORREDOR SANCHEZ
 * The type Acd spring ejercicio 2 tutorial application.
 */
@SpringBootApplication
public class AcdSpringEjercicio2TutorialApplication implements CommandLineRunner {

    @Autowired
    private PersonaRepository repository;

    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {
        SpringApplication.run(AcdSpringEjercicio2TutorialApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        repository.deleteAll();

        // save a couple of customers
        repository.save(new Persona("Alice", "Smith"));
        repository.save(new Persona("Bob", "Smith"));

        // fetch all customers
        System.out.println("Customers found with findAll():");
        System.out.println("-------------------------------");
        for (Persona persona : repository.findAll()) {
            System.out.println(persona);
        }
        System.out.println();
    }
}
