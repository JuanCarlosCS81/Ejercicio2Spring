package com.example.acdspringejercicio2tutorial;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;
//RespositoryRestResource ya incluye los metodos CRUD
@RepositoryRestResource(collectionResourceRel = "persona", path = "persona")
public interface PersonaRepository extends MongoRepository<Persona,String> {
    //@RestResource es para hacer custom de CRUD, si se hace fuera de @RespositoryRestResource se pone en cada @RestResource un path custom
    @RestResource(exported = true, path = "deleteBy")
    void deletePersonaByFirstNameAndLastName(@Param("nombre") String nombre,@Param("apellido") String apellido);

    List<Persona> findPersonaByFirstName(@Param("nombre") String nombre);
    List<Persona> findPersonaByLastName(@Param("apellido") String apellido);
}
